<?php
    $dbuser="root";
    $dbpass="";
    $host="localhost";
    $db="internetbanking";
    $mysqli=new mysqli($host,$dbuser, $dbpass, $db);
